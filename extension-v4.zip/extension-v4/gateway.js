// gateway.js — gọi AI qua n8n Gateway (thay cho gọi thẳng nhà cung cấp LLM bằng API key trong tiện ích).
// Dùng tài khoản Firebase mà học sinh đã đăng nhập trong tiện ích (lấy idToken qua getValidIdToken).
// Prompt, model và giới hạn do n8n quyết định (node "Config", hồ sơ "chrome-extension").
import { getValidIdToken } from "./firestore-rest.js";

const GATEWAY_BASE_URL = "https://n8nhosting-67079049.phoaify.com/webhook"; // URL webhook n8n, không có "/" ở cuối
const RENEW_BEFORE_MS = 60 * 1000;
const TOKEN_KEY = "gatewayToken";

class GatewayError extends Error {
  constructor(code, status) { super(code); this.code = code; this.status = status || 0; }
}

async function postJson(path, body) {
  let res;
  try {
    res = await fetch(GATEWAY_BASE_URL + path, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=UTF-8" },
      body: JSON.stringify(body),
    });
  } catch (e) {
    throw new GatewayError("network_error");
  }
  let data = null;
  try { data = await res.json(); } catch (e) { /* không phải JSON */ }
  return { status: res.status, data };
}

// Service worker MV3 hay bị tắt khi rảnh -> lưu token vào storage.session (mất khi đóng trình duyệt) để khỏi xin lại liên tục.
const store = chrome.storage.session || chrome.storage.local;
async function readCached() {
  const o = await store.get({ [TOKEN_KEY]: null });
  return o[TOKEN_KEY];
}

async function fetchToken() {
  const tokens = await getValidIdToken();
  if (!tokens || !tokens.idToken) throw new GatewayError("not_logged_in");
  const { status, data } = await postJson("/popai-gw-token", {
    id_token: tokens.idToken,
    page_url: chrome.runtime.getURL(""),
  });
  if (status !== 200 || !data || !data.token) throw new GatewayError((data && data.error) || "token_http_" + status, status);
  const cached = { token: data.token, expMs: Date.now() + (Number(data.expires_in) || 300) * 1000 };
  await store.set({ [TOKEN_KEY]: cached });
  return cached.token;
}

async function ensureToken(force = false) {
  if (!force) {
    const c = await readCached();
    if (c && c.expMs - Date.now() > RENEW_BEFORE_MS) return c.token;
  }
  return fetchToken();
}

export function friendlyError(err) {
  const code = (err && err.code) || "";
  const map = {
    not_logged_in: "Bạn cần đăng nhập tiện ích AI SMART trước (mở biểu tượng tiện ích để đăng nhập).",
    network_error: "Không kết nối được tới máy chủ AI, hãy kiểm tra mạng rồi thử lại.",
    user_rate_limit: "Bạn bấm hơi nhanh, đợi một chút rồi thử lại nhé.",
    user_daily_limit: "Hôm nay bạn đã dùng hết lượt AI. Mai quay lại nhé!",
    web_daily_cap: "Hôm nay hệ thống AI đã hết lượt dùng. Thử lại vào ngày mai nhé.",
    daily_cap_reached: "Hôm nay hệ thống AI đã hết lượt dùng. Thử lại vào ngày mai nhé.",
    gateway_disabled: "AI đang tạm dừng để bảo trì. Thử lại sau nhé.",
    message_too_long: "Câu hỏi quá dài, hãy rút gọn lại.",
    too_many_requests: "Có quá nhiều yêu cầu, đợi một chút rồi thử lại.",
    llm_unavailable: "AI đang quá tải, thử lại sau ít phút nhé.",
  };
  return map[code] || ("AI đang gặp sự cố (" + (code || "lỗi không rõ") + "). Thử lại sau nhé.");
}

/** Chạy một "tác vụ" định nghĩa sẵn trên n8n (vd. "rewrite") và trả về nội dung trả lời. */
export async function runTask(task, message) {
  for (let attempt = 0; attempt < 2; attempt++) {
    const token = await ensureToken(attempt > 0);
    const { status, data } = await postJson("/popai-gw-chat", { token, task, message, page_url: chrome.runtime.getURL("") });
    if (status === 200 && data && typeof data.reply === "string") return data.reply;
    const code = (data && data.error) || "http_" + status;
    if (status === 401 && attempt === 0) continue; // token hết hạn -> xin mới, thử lại 1 lần
    throw new GatewayError(code, status);
  }
  throw new GatewayError("token_refresh_failed");
}
