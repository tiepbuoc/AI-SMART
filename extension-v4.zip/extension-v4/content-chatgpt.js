// content-chatgpt.js
// Theo dõi các tin nhắn do NGƯỜI DÙNG gửi trên chatgpt.com / chat.openai.com,
// và chèn panel gợi ý SMART cạnh ô nhập.

(function () {
  console.log("[AI SMART] content-chatgpt đã nạp", location.href);
  // ChatGPT đánh dấu tin nhắn người dùng bằng data-message-author-role="user" (thử thêm vài selector dự phòng)
  const USER_MESSAGE_SELECTOR = [
    '[data-message-author-role="user"]',
    'article[data-turn="user"]',
    '[data-turn="user"]',
  ].join(", ");

  const INPUT_SELECTORS = [
    "#prompt-textarea",
    'div.ProseMirror[contenteditable="true"]',
    'div[role="textbox"][contenteditable="true"]',
    'textarea[data-testid="chat-input-textarea"]',
    "form textarea",
  ];

  // Chống lưu trùng giữa 2 cách bắt (lúc bấm gửi + quét DOM)
  const norm = (t) => (t || "").replace(/\s+/g, " ").trim();
  let lastSaved = { t: "", at: 0 };
  function save(text) {
    const n = norm(text);
    if (!n) return;
    const now = Date.now();
    if (n === lastSaved.t && now - lastSaved.at < 8000) return;
    lastSaved = { t: n, at: now };
    console.log("[AI SMART] lưu câu hỏi:", n.slice(0, 60));
    aiLoggerSaveEntry("chatgpt", text);
  }

  // Cách 1: quét DOM. ChatGPT có thể tạo phần tử trước rồi mới đổ chữ vào -> thử lại tới 10 lần
  function readWithRetry(el, tries) {
    const text = el.innerText || el.textContent || "";
    if (norm(text)) return save(text);
    if (tries > 0) setTimeout(() => readWithRetry(el, tries - 1), 300);
  }
  aiLoggerObserveNewMatches(
    USER_MESSAGE_SELECTOR,
    (el) => readWithRetry(el, 10),
    { debounceMs: 200 }
  );

  setTimeout(() => console.log("[AI SMART] số tin nhắn user tìm thấy:", document.querySelectorAll(USER_MESSAGE_SELECTOR).length, "| ô nhập:", !!document.querySelector(INPUT_SELECTORS.join(","))), 4000);

  // Cách 2 (không phụ thuộc cấu trúc tin nhắn): lấy chữ trong ô nhập ngay lúc bấm Enter / nút Gửi
  function currentInputText() {
    for (const sel of INPUT_SELECTORS) {
      const el = document.querySelector(sel);
      if (el) {
        const t = el.matches("textarea") ? el.value : el.innerText;
        if (norm(t)) return t;
      }
    }
    return "";
  }
  document.addEventListener(
    "keydown",
    (e) => {
      if (e.key !== "Enter" || e.shiftKey || e.isComposing) return;
      const t = e.target;
      if (!t || !t.closest || !t.closest("#prompt-textarea, form, [contenteditable='true']")) return;
      save(currentInputText());
    },
    true
  );
  document.addEventListener(
    "click",
    (e) => {
      const b = e.target && e.target.closest && e.target.closest(
        'button[data-testid="send-button"], button[aria-label*="Send" i], button[aria-label*="Gửi"]'
      );
      if (b) save(currentInputText());
    },
    true
  );

  // Ô nhập của ChatGPT: có thể là <div id="prompt-textarea" contenteditable>
  // hoặc <textarea> tuỳ phiên bản giao diện — thử theo thứ tự.
  initSmartHint({
    inputSelectors: [
      "#prompt-textarea",
      'div.ProseMirror[contenteditable="true"]',
      'div[role="textbox"][contenteditable="true"]',
      'textarea[data-testid="chat-input-textarea"]',
      "form textarea",
    ],
    getText: (el) => (el.matches("textarea") ? el.value : el.innerText),
    setText: (el, text) => {
      if (el.matches("textarea")) {
        el.value = text;
        el.dispatchEvent(new Event("input", { bubbles: true }));
      } else {
        // ProseMirror: dùng execCommand để trình soạn thảo nhận đúng nội dung mới
        el.focus();
        document.execCommand("selectAll", false, null);
        const ok = document.execCommand("insertText", false, text);
        if (!ok) {
          el.innerText = text;
          el.dispatchEvent(new InputEvent("input", { bubbles: true }));
        }
      }
    },
  });
})();
