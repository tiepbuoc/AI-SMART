// background.js — MV3 service worker (type: module)
import { getValidIdToken, writeEntryToFirestore } from "./firestore-rest.js";
import { runTask, friendlyError } from "./gateway.js";

// ============ 1. Mở tab đăng nhập/đồng ý tự động khi vừa cài tiện ích ============
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html") });
  }
});

// ============ 2. Đồng bộ nền liên tục (không cần mở popup) ============
async function syncUnsyncedEntries() {
  const { syncConsent } = await chrome.storage.local.get({ syncConsent: false });
  if (!syncConsent) return;

  const tokens = await getValidIdToken();
  if (!tokens) return;

  const { entries = [] } = await chrome.storage.local.get({ entries: [] });
  const unsynced = entries.filter((e) => !e.synced);
  if (unsynced.length === 0) return;

  let changed = false;
  for (const entry of unsynced) {
    try {
      await writeEntryToFirestore(tokens.uid, tokens.idToken, entry);
      entry.synced = true;
      changed = true;
    } catch (e) {
      console.error("Đồng bộ entry thất bại:", e.message);
      break; // dừng lại, thử lại ở lần sync kế tiếp
    }
  }

  if (changed) {
    const { entries: latest = [] } = await chrome.storage.local.get({ entries: [] });
    const merged = latest.map((e) => {
      const match = unsynced.find((u) => u.id === e.id && u.synced);
      return match ? { ...e, synced: true } : e;
    });
    await chrome.storage.local.set({ entries: merged });
  }
}

// Đồng bộ ngay khi có entry mới được lưu (gần như tức thời)
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.entries) {
    syncUnsyncedEntries();
  }
});

// Đồng bộ định kỳ dự phòng (phòng khi bỏ lỡ sự kiện onChanged, hoặc lần trước lỗi mạng)
chrome.alarms.create("ai-smart-sync", { periodInMinutes: 2 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "ai-smart-sync") syncUnsyncedEntries();
});

// ============ 3. Viết lại câu hỏi theo khung SMART (qua n8n Gateway) ============
// Không còn API key trong tiện ích: prompt, model và giới hạn do n8n quyết định (xem gateway.js).
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "rewritePrompt") {
    handleRewrite(message.text)
      .then((result) => sendResponse(result))
      .catch((err) => sendResponse({ error: err.message }));
    return true;
  }
  if (message?.type === "onboardingComplete") {
    syncUnsyncedEntries();
  }
});

async function handleRewrite(text) {
  try {
    const rewritten = (await runTask("rewrite", text)).trim();
    return { rewritten: rewritten || text };
  } catch (e) {
    throw new Error(friendlyError(e));
  }
}
